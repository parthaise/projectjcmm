"""Generate a synthetic building-energy dataset for software smoke-testing only."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd

def make_demo_data(n_days=180, seed=42):
    rng = np.random.default_rng(seed)
    n = n_days * 24
    ts = pd.date_range("2023-01-01", periods=n, freq="h")
    hour = ts.hour.to_numpy()
    doy = ts.dayofyear.to_numpy()
    dow = ts.dayofweek.to_numpy()
    outdoor = 17 + 8*np.sin(2*np.pi*(doy-80)/365) + 4*np.sin(2*np.pi*(hour-8)/24) + rng.normal(0, 1.3, n)
    occupancy = np.where((hour >= 8) & (hour <= 18) & (dow < 5), rng.integers(5, 45, n), rng.integers(0, 5, n))
    humidity = np.clip(55 + 12*np.sin(2*np.pi*doy/365) + rng.normal(0, 7, n), 20, 95)
    solar = np.maximum(0, 650*np.sin(np.pi*(hour-6)/12)) * (0.65 + 0.35*np.sin(2*np.pi*doy/365))
    setpoint = np.where((hour >= 7) & (hour <= 19), 22.0, 24.0)
    indoor = setpoint + 0.18*(outdoor-22) + 0.008*occupancy - 0.0008*solar + rng.normal(0, 0.7, n)
    heating_cooling = 0.75*np.abs(outdoor-setpoint) + 0.45*np.abs(indoor-setpoint)
    energy = 7.5 + heating_cooling + 0.045*occupancy + 0.0025*solar + 0.018*humidity + rng.normal(0, 0.8, n)
    energy = np.maximum(0.2, energy)
    return pd.DataFrame({
        "timestamp": ts,
        "energy_kwh": energy,
        "indoor_temp": indoor,
        "outdoor_temp": outdoor,
        "humidity": humidity,
        "occupancy": occupancy,
        "hvac_setpoint": setpoint,
        "solar_irradiance": solar,
        "day_of_week": dow,
        "hour": hour,
    })

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="data/demo_building_energy.csv")
    p.add_argument("--days", type=int, default=180)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df = make_demo_data(a.days, a.seed)
    df.to_csv(out, index=False)
    print(f"Wrote {len(df)} synthetic demo rows to {out}")
