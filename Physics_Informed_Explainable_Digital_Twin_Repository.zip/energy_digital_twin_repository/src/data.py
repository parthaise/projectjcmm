from dataclasses import dataclass
from typing import List, Tuple
import pandas as pd
from sklearn.preprocessing import StandardScaler

REQUIRED = [
    "timestamp", "energy_kwh", "indoor_temp", "outdoor_temp", "humidity",
    "occupancy", "hvac_setpoint", "solar_irradiance"
]
BASE_FEATURES = [
    "indoor_temp", "outdoor_temp", "humidity", "occupancy",
    "hvac_setpoint", "solar_irradiance", "hour", "day_of_week"
]

@dataclass
class PreparedData:
    frame: pd.DataFrame
    feature_cols: List[str]
    x_train: object
    x_val: object
    x_test: object
    y_train: object
    y_val: object
    y_test: object
    scaler_x: StandardScaler
    scaler_y: StandardScaler
    train_frame: pd.DataFrame
    val_frame: pd.DataFrame
    test_frame: pd.DataFrame

def load_and_split(path: str, train_fraction=0.70, val_fraction=0.15) -> PreparedData:
    df = pd.read_csv(path)
    missing = set(REQUIRED) - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}. Adapt src/data.py to your dataset; do not fabricate fields.")
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="raise")
    df = df.sort_values("timestamp").drop_duplicates(subset=["timestamp"]).reset_index(drop=True)
    if "hour" not in df:
        df["hour"] = df["timestamp"].dt.hour
    if "day_of_week" not in df:
        df["day_of_week"] = df["timestamp"].dt.dayofweek
    df = df.dropna(subset=BASE_FEATURES + ["energy_kwh"]).reset_index(drop=True)
    n = len(df)
    n_train = int(n * train_fraction)
    n_val = int(n * val_fraction)
    if n_train < 10 or n - n_train - n_val < 5:
        raise ValueError("Not enough rows for chronological train/validation/test split.")
    train = df.iloc[:n_train].copy()
    val = df.iloc[n_train:n_train+n_val].copy()
    test = df.iloc[n_train+n_val:].copy()
    sx, sy = StandardScaler(), StandardScaler()
    x_train = sx.fit_transform(train[BASE_FEATURES])
    x_val = sx.transform(val[BASE_FEATURES])
    x_test = sx.transform(test[BASE_FEATURES])
    y_train = sy.fit_transform(train[["energy_kwh"]]).ravel()
    y_val = sy.transform(val[["energy_kwh"]]).ravel()
    y_test = sy.transform(test[["energy_kwh"]]).ravel()
    return PreparedData(df, BASE_FEATURES, x_train, x_val, x_test, y_train, y_val, y_test,
                        sx, sy, train, val, test)
