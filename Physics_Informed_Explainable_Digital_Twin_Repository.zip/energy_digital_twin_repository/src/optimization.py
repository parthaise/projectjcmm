import numpy as np

def optimize_setpoints(frame, weights=(0.40, 0.35, 0.25), comfort_limit_c=2.0,
                       setpoint_offsets=(-2, -1, 0, 1, 2), carbon_factor=0.35,
                       energy_price=1.0):
    """
    Transparent grid-search demonstrator. Evaluates setpoint offsets using an
    empirical demand proxy and a comfort-deviation penalty. Replace this proxy
    with the trained model/validated building simulator for manuscript experiments.
    """
    alpha, beta, gamma = weights
    if not np.isclose(alpha + beta + gamma, 1.0):
        raise ValueError("Optimization weights must sum to 1.")
    base = frame.copy()
    baseline_energy = np.maximum(
        0.2,
        7.5 + 0.75*np.abs(base["outdoor_temp"]-base["hvac_setpoint"]) +
        0.45*np.abs(base["indoor_temp"]-base["hvac_setpoint"]) +
        0.045*base["occupancy"] + 0.0025*base["solar_irradiance"]
    ).to_numpy()
    best = None
    for offset in setpoint_offsets:
        candidate_setpoint = base["hvac_setpoint"].to_numpy() + float(offset)
        energy = np.maximum(
            0.2,
            7.5 + 0.75*np.abs(base["outdoor_temp"].to_numpy()-candidate_setpoint) +
            0.45*np.abs(base["indoor_temp"].to_numpy()-candidate_setpoint) +
            0.045*base["occupancy"].to_numpy() + 0.0025*base["solar_irradiance"].to_numpy()
        )
        comfort_deviation = np.abs(base["indoor_temp"].to_numpy()-candidate_setpoint)
        comfort_violation = np.maximum(0, comfort_deviation-comfort_limit_c)
        comfort_penalty = float(np.mean(comfort_violation))
        energy_reduction = float((baseline_energy.mean()-energy.mean()) / max(baseline_energy.mean(), 1e-8))
        cost_reduction = energy_reduction  # same tariff assumed; replace if time-varying tariffs are available
        carbon_reduction = energy_reduction # constant emissions factor assumed
        objective = -(alpha*energy_reduction + beta*cost_reduction + gamma*carbon_reduction) + 2.0*comfort_penalty
        record = {
            "setpoint_offset_C": float(offset),
            "mean_baseline_energy_proxy": float(baseline_energy.mean()),
            "mean_candidate_energy_proxy": float(energy.mean()),
            "energy_reduction_percent": 100*energy_reduction,
            "cost_reduction_percent": 100*cost_reduction,
            "carbon_reduction_percent": 100*carbon_reduction,
            "mean_comfort_deviation_C": float(np.mean(comfort_deviation)),
            "comfort_violation_penalty": comfort_penalty,
            "objective": float(objective),
            "energy_price_assumption": energy_price,
            "carbon_factor_assumption": carbon_factor
        }
        if best is None or record["objective"] < best["objective"]:
            best = record
    return best
