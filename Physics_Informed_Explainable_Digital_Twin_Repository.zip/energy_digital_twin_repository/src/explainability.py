import pandas as pd
from sklearn.inspection import permutation_importance

def permutation_importance_table(model, x_test, y_test, feature_names, seed=42):
    result = permutation_importance(model, x_test, y_test, n_repeats=10,
                                    random_state=seed, scoring="neg_mean_absolute_error")
    out = pd.DataFrame({
        "feature": feature_names,
        "importance_mean": result.importances_mean,
        "importance_std": result.importances_std
    }).sort_values("importance_mean", ascending=False)
    return out

def try_shap(model, x_background, x_explain, feature_names, out_csv):
    """Optional SHAP export for sklearn-compatible models. Returns False if unavailable."""
    try:
        import shap
        explainer = shap.Explainer(model, x_background)
        values = explainer(x_explain)
        mean_abs = abs(values.values).mean(axis=0)
        pd.DataFrame({"feature": feature_names, "mean_abs_shap": mean_abs}) \
          .sort_values("mean_abs_shap", ascending=False).to_csv(out_csv, index=False)
        return True
    except Exception as exc:
        print(f"SHAP unavailable or unsupported for this model ({exc}); using permutation importance.")
        return False
