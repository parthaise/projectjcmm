import copy
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.neural_network import MLPRegressor

class EnergyMLP(nn.Module):
    def __init__(self, n_features, hidden=(128, 64, 32), dropout=0.2):
        super().__init__()
        layers = []
        prev = n_features
        for h in hidden:
            layers.extend([nn.Linear(prev, h), nn.ReLU(), nn.Dropout(dropout)])
            prev = h
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)

def physics_residual(x_raw, y_pred_kwh):
    """
    Simplified thermal-balance proxy. This residual is illustrative and must be
    adapted/calibrated to a validated building thermal model before publication.
    It penalizes inconsistency between energy demand and a temperature/setpoint/
    weather/occupancy proxy; it is not a universal first-principles equation.
    x_raw columns follow: indoor_temp, outdoor_temp, humidity, occupancy,
    hvac_setpoint, solar_irradiance, hour, day_of_week.
    """
    indoor = x_raw[:, 0]
    outdoor = x_raw[:, 1]
    occupancy = x_raw[:, 3]
    setpoint = x_raw[:, 4]
    solar = x_raw[:, 5]
    # Empirical proxy for thermal load; coefficients are starting values only.
    thermal_proxy = 7.5 + 0.75*torch.abs(outdoor-setpoint) + \
                    0.45*torch.abs(indoor-setpoint) + 0.045*occupancy + 0.0025*solar
    return y_pred_kwh - thermal_proxy

def train_pinn(x_train_scaled, y_train_scaled, x_val_scaled, y_val_scaled,
               x_train_raw, y_train_raw, x_val_raw, y_val_raw,
               scaler_y, lambda_phys=0.02, epochs=100, batch_size=32,
               lr=1e-3, seed=42, device="cpu"):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = EnergyMLP(x_train_scaled.shape[1]).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    mse = nn.MSELoss()
    # Raw features are passed alongside scaled inputs so the physics term stays interpretable.
    ds = TensorDataset(torch.tensor(x_train_scaled, dtype=torch.float32),
                       torch.tensor(y_train_scaled, dtype=torch.float32),
                       torch.tensor(x_train_raw, dtype=torch.float32),
                       torch.tensor(y_train_raw, dtype=torch.float32))
    loader = DataLoader(ds, batch_size=batch_size, shuffle=True)
    best_state, best_val, patience, wait = None, float("inf"), 15, 0
    for _ in range(epochs):
        model.train()
        for xs, ys, xr, yr in loader:
            xs, ys, xr, yr = xs.to(device), ys.to(device), xr.to(device), yr.to(device)
            pred_scaled = model(xs)
            data_loss = mse(pred_scaled, ys)
            pred_kwh = torch.tensor(scaler_y.mean_[0], device=device) + \
                       pred_scaled * torch.tensor(scaler_y.scale_[0], device=device)
            phys_loss = torch.mean(physics_residual(xr, pred_kwh) ** 2) / 100.0
            loss = data_loss + lambda_phys * phys_loss
            opt.zero_grad()
            loss.backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            pv = model(torch.tensor(x_val_scaled, dtype=torch.float32, device=device))
            vloss = mse(pv, torch.tensor(y_val_scaled, dtype=torch.float32, device=device)).item()
        if vloss < best_val:
            best_val = vloss
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                break
    if best_state:
        model.load_state_dict(best_state)
    return model

def predict_pinn(model, x_scaled, scaler_y, device="cpu"):
    model.eval()
    with torch.no_grad():
        p = model(torch.tensor(x_scaled, dtype=torch.float32, device=device)).cpu().numpy()
    return scaler_y.inverse_transform(p.reshape(-1, 1)).ravel()

def fit_baselines(x_train, y_train, seed=42):
    return {
        "MLP": MLPRegressor(hidden_layer_sizes=(128, 64, 32), activation="relu",
                            solver="adam", learning_rate_init=1e-3, max_iter=500,
                            early_stopping=True, random_state=seed),
        "RandomForest": RandomForestRegressor(n_estimators=250, min_samples_leaf=2,
                                              random_state=seed, n_jobs=-1),
        "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=250,
                                                              learning_rate=0.06,
                                                              random_state=seed)
    }
