# Physics-Informed Explainable Digital Twin for Building Energy Optimization

This repository provides a runnable reference implementation for a building-energy prediction and optimization workflow with:
- a reproducible demo dataset generator;
- chronological train/validation/test splitting;
- baseline regression models and a physics-informed neural network (PINN);
- a simple thermal-balance residual used as a physics regularizer;
- SHAP-based explanations when `shap` is installed (permutation importance fallback);
- weighted energy/cost/carbon optimization under a comfort constraint;
- evaluation metrics, ablation runs, and CSV/JSON outputs.

## Important scientific-use note

The included demo data are **synthetic** and are only for testing that the software runs. They are not the ASHRAE Great Energy Predictor III or Building Data Genome Project 2 dataset, and outputs from the demo must not be reported as experimental findings in a manuscript. For publication, obtain the real dataset from its official source, check its license/terms, map its columns to the schema below, rerun the pipeline, and report the actual outputs.

This is a reference implementation, not evidence that a physical Digital Twin was deployed. If no physical building/sensor system is connected, describe it as a simulation/data-driven Digital Twin prototype.

## Quick start

Python 3.10 or 3.11 recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python generate_demo_data.py
python run_experiment.py --data data/demo_building_energy.csv --out results
```

Outputs are written to `results/`:
- `metrics.csv`: regression metrics for the held-out chronological test period;
- `predictions.csv`: test targets and predictions;
- `optimization_summary.json`: baseline vs optimized energy/cost/carbon and comfort;
- `feature_importance.csv`: permutation importance (SHAP is optional);
- `ablation.csv`: component/regularization comparison;
- `run_config.json`: split, seed, and hyperparameters.

## Real dataset schema

The pipeline expects one row per timestamp/zone/meter and these columns:

| Column | Meaning |
|---|---|
| `timestamp` | parseable timestamp |
| `energy_kwh` | measured energy consumption (target) |
| `indoor_temp` | indoor temperature, °C |
| `outdoor_temp` | outdoor temperature, °C |
| `humidity` | relative humidity, % |
| `occupancy` | occupancy count or normalized occupancy |
| `hvac_setpoint` | HVAC setpoint, °C |
| `solar_irradiance` | solar irradiance or a consistently defined proxy |
| `day_of_week` | optional; generated from timestamp if absent |
| `hour` | optional; generated from timestamp if absent |

If your source dataset does not contain indoor temperature, HVAC setpoint, occupancy, or solar irradiance, do not invent measured columns. Modify the feature list and physics term to match available data and the actual system model. The provided physics residual is a simplified thermal-balance proxy and must be calibrated/validated for the studied building.

## Dataset guidance

Download third-party data from the provider's official source and follow its terms. Do not commit restricted or large third-party data to this repository. Instead, document the source, version, license, preprocessing, and download instructions. The sample generator creates only synthetic demo data.

## Reproducibility and reporting

- The split is chronological to reduce leakage from future observations.
- All preprocessing is fitted on training data only.
- Set `--seed` for deterministic initialization where supported.
- Report results from the real dataset, including repeated-run means/standard deviations if those experiments are actually performed.
- Do not claim statistical significance unless the tests were run and the p-values are reported.
- Optimization uses a grid over setpoint offsets and occupancy-aware control adjustments. It is a demonstrator, not a certified HVAC controller; do not deploy without domain validation and safety constraints.

## Repository DOI

After uploading this repository to Zenodo and publishing a release, replace the placeholder DOI in `CITATION.cff` and in the manuscript's Data and Code Availability statement with the DOI assigned by Zenodo.
