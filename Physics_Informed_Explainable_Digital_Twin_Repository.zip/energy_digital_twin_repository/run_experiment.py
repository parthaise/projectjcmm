import argparse, json, os, sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch

from src.data import load_and_split
from src.models import train_pinn, predict_pinn, fit_baselines
from src.metrics import regression_metrics
from src.optimization import optimize_setpoints
from src.explainability import permutation_importance_table, try_shap

def main():
    p = argparse.ArgumentParser(description="Run building energy prediction demo/experiment.")
    p.add_argument("--data", default="data/demo_building_energy.csv")
    p.add_argument("--out", default="results")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--lambda-phys", type=float, default=0.02)
    p.add_argument("--device", default="cpu")
    args = p.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    np.random.seed(args.seed); torch.manual_seed(args.seed)
    d = load_and_split(args.data)
    # Raw features are retained for physics residual computation.
    x_train_raw = d.train_frame[d.feature_cols].to_numpy(dtype=np.float32)
    x_val_raw = d.val_frame[d.feature_cols].to_numpy(dtype=np.float32)
    x_test_raw = d.test_frame[d.feature_cols].to_numpy(dtype=np.float32)

    metrics = []
    predictions = pd.DataFrame({
        "timestamp": d.test_frame["timestamp"].to_numpy(),
        "actual_energy_kwh": d.test_frame["energy_kwh"].to_numpy()
    })
    baseline_models = fit_baselines(d.x_train, d.y_train, args.seed)
    fitted_baselines = {}
    for name, model in baseline_models.items():
        model.fit(d.x_train, d.y_train)
        pred = model.predict(d.x_test)
        pred_kwh = d.scaler_y.inverse_transform(np.asarray(pred).reshape(-1, 1)).ravel()
        actual_kwh = d.test_frame["energy_kwh"].to_numpy()
        metrics.append({"model": name, **regression_metrics(actual_kwh, pred_kwh)})
        predictions[f"{name}_prediction_kwh"] = pred_kwh
        fitted_baselines[name] = model

    pinn = train_pinn(
        d.x_train, d.y_train, d.x_val, d.y_val,
        x_train_raw, d.train_frame["energy_kwh"].to_numpy(dtype=np.float32),
        x_val_raw, d.val_frame["energy_kwh"].to_numpy(dtype=np.float32),
        d.scaler_y, lambda_phys=args.lambda_phys, epochs=args.epochs,
        seed=args.seed, device=args.device
    )
    pinn_pred = predict_pinn(pinn, d.x_test, d.scaler_y, args.device)
    actual_kwh = d.test_frame["energy_kwh"].to_numpy()
    metrics.append({"model": "Proposed_PINN", **regression_metrics(actual_kwh, pinn_pred)})
    predictions["Proposed_PINN_prediction_kwh"] = pinn_pred
    pd.DataFrame(metrics).to_csv(out / "metrics.csv", index=False)
    predictions.to_csv(out / "predictions.csv", index=False)

    # Explainability for the strongest tree baseline; SHAP is optional.
    explain_model = fitted_baselines["RandomForest"]
    imp = permutation_importance_table(explain_model, d.x_test, d.y_test, d.feature_cols, args.seed)
    imp.to_csv(out / "feature_importance.csv", index=False)
    try_shap(explain_model, d.x_train[:min(200, len(d.x_train))],
             d.x_test[:min(200, len(d.x_test))], d.feature_cols, out / "shap_importance.csv")

    # Optimization demo uses only held-out test rows. Its proxy must be replaced with a
    # validated model/simulator before using its outputs as research results.
    opt = optimize_setpoints(d.test_frame)
    with open(out / "optimization_summary.json", "w", encoding="utf-8") as f:
        json.dump(opt, f, indent=2)

    # Ablation: vary physics penalty. Each run is retrained using the same chronological split.
    ablation = []
    for lam in [0.0, args.lambda_phys, 0.05]:
        model = train_pinn(
            d.x_train, d.y_train, d.x_val, d.y_val,
            x_train_raw, d.train_frame["energy_kwh"].to_numpy(dtype=np.float32),
            x_val_raw, d.val_frame["energy_kwh"].to_numpy(dtype=np.float32),
            d.scaler_y, lambda_phys=lam, epochs=args.epochs,
            seed=args.seed, device=args.device
        )
        pred = predict_pinn(model, d.x_test, d.scaler_y, args.device)
        ablation.append({"lambda_phys": lam, **regression_metrics(actual_kwh, pred)})
    pd.DataFrame(ablation).to_csv(out / "ablation.csv", index=False)

    config = {
        "data_path": args.data, "seed": args.seed, "epochs": args.epochs,
        "lambda_phys": args.lambda_phys, "device": args.device,
        "split": {"train": 0.70, "validation": 0.15, "test": 0.15},
        "features": d.feature_cols,
        "note": "Interpret outputs according to dataset provenance. Synthetic demo outputs are not publication results."
    }
    with open(out / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, default=str)
    print(f"Completed. Results saved to: {out.resolve()}")
    print(pd.DataFrame(metrics).to_string(index=False))

if __name__ == "__main__":
    main()
